<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
    <style>

    </style>
</head>

<body style="padding:2px 16px;">
    <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <div style="box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
        <h3>Follow th following steps</h3>
        <ol>
            <li>Go to mpesa</li>
            <li>Lipa na mpesa</li>
            <li>Paybill</li>
            <li>Enter business number <strong>247247</strong></li>
            <li>Enter account number <strong>0769525570</strong></li>
            <li>Confirm Payment</li>


        </ol>

    </div>

    <script src="" async defer></script>
</body>

</html>